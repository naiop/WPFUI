﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace VirtualizingPPanel
{
    public class Wwrappanel:WrapPanel
    {
        protected override Size MeasureOverride(Size constraint)
        {
            Debug.WriteLine(this.InternalChildren.Count + "---------------");
            return base.MeasureOverride(constraint);
        }
    }
}
